import random
import heapq
import MapObjectIDs as ids

# 전체 맵 (0=좀비, 1=길, 2=숲(장애물), 9=플레이어)
game_map = [
    [0, 1, 1, 1, 1, 2, 1, 2, 1, 2],
    [2, 1, 1, 1, 2, 2, 1, 1, 1, 1],
    [1, 2, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 2],
    [1, 1, 1, 1, 2, 1, 2, 1, 1, 2],
    [1, 1, 1, 1, 2, 2, 2, 2, 1, 2],
    [1, 1, 1, 1, 1, 1, 2, 2, 2, 2],
    [1, 1, 1, 1, 2, 2, 2, 2, 2, 2],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 2],
    [2, 1, 2, 1, 1, 1, 1, 1, 1, 9]
]

# 상, 하, 좌, 우, 제자리 이동 방향
directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (0, 0)]

#휴리스틱함수 , 맨해튼거리 측정용
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

#전체 크기를 정의하기위한 바운드함수
def in_bounds(position, map_height, map_width):
    row, col = position
    return 0 <= row < map_height and 0 <= col < map_width

#좀비의 제한된 시야를 위한 함수
def get_vision_map(game_map, zombie_position, vision_radius):
    map_height = len(game_map)
    map_width = len(game_map[0])
    road = ids.ROAD

    vision_size = 2 * vision_radius + 1

    vision_map = [[road] * vision_size for _ in range(vision_size)]

    zombie_rel_pos = None
    player_rel_pos = None

    start_row = zombie_position[0] - vision_radius
    start_col = zombie_position[1] - vision_radius

    for d_row in range(vision_size):
        for d_col in range(vision_size):
            rel_row = d_row - vision_radius
            rel_col = d_col - vision_radius

            if abs(rel_row) + abs(rel_col) <= vision_radius:
                map_row = start_row + d_row
                map_col = start_col + d_col

                if 0 <= map_row < map_height and 0 <= map_col < map_width:
                    vision_map[d_row][d_col] = game_map[map_row][map_col]

                    if (map_row, map_col) == zombie_position:
                        zombie_rel_pos = (d_row, d_col)
                    if game_map[map_row][map_col] == 9:
                        player_rel_pos = (d_row, d_col)

    return vision_map, zombie_rel_pos, player_rel_pos

#A star 함수 -> 시야범위안에 들어왔을때 최적경로계산을위한함수, 움직일때마다 장애물,위치가 갱신되므로 경로도갱신된다.
def a_star_partial(start, goal, vision_map):
    map_height = len(vision_map)
    map_width = len(vision_map[0])

    open_list = []
    heapq.heappush(open_list, (0, start))

    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}

    while open_list:
        _, current = heapq.heappop(open_list)
        if current == goal:
            path = []
            while current != start:
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path

        for d_row, d_col in directions[:-1]:
            neighbor = (current[0] + d_row, current[1] + d_col)
            if 0 <= neighbor[0] < map_height and 0 <= neighbor[1] < map_width:
                if vision_map[neighbor[0]][neighbor[1]] == 2:
                    continue
                tentative_g = g_score[current] + 1
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + heuristic(neighbor, goal)
                    heapq.heappush(open_list, (f_score[neighbor], neighbor))

    return None

#좀비의 움직임처리. 시야내에들어오면 a star함수처리. 시야밖에서 랜덤이동처리
def zombie_tick(zombie_position, player_position, game_map, vision_radius):
    vision_map, zombie_rel_pos, player_rel_pos = get_vision_map(game_map, zombie_position, vision_radius)

    if zombie_rel_pos is None:
        return zombie_position

    moved = False
    new_position = zombie_position

    if player_rel_pos is not None:
        path = a_star_partial(zombie_rel_pos, player_rel_pos, vision_map)
        if path and len(path) > 0:
            next_rel = path[0]
            new_position = (
                zombie_position[0] - vision_radius + next_rel[0],
                zombie_position[1] - vision_radius + next_rel[1]
            )
            moved = True

    if not moved:
        candidates = []
        for d_row, d_col in directions:
            next_row = zombie_position[0] + d_row
            next_col = zombie_position[1] + d_col
            if in_bounds((next_row, next_col), len(game_map), len(game_map[0])) and game_map[next_row][next_col] != 2:
                candidates.append((next_row, next_col))
        if candidates:
            new_position = random.choice(candidates)

    if new_position != zombie_position:
        old_row, old_col = zombie_position
        if game_map[old_row][old_col] == 0:
            game_map[old_row][old_col] = 1
        new_row, new_col = new_position
        if game_map[new_row][new_col] != 9:
            game_map[new_row][new_col] = 0

    return new_position

# # 지금당장의 맵처리. 나중에 빠짐
# def print_map(game_map):
#     for row in game_map:
#         for val in row:
#             if val == 0:
#                 print("♟️", end="")
#             elif val == 1:
#                 print("  ", end="")
#             elif val == 2:
#                 print("🌳", end="")
#             elif val == 9:
#                 print("🏁", end="")
#         print()
#     print("-" * 10)

#좀비와 플레이어의 초기 부활 위치를 설정.
def find_position(game_map, target):
    for row in range(len(game_map)):
        for col in range(len(game_map[0])):
            if game_map[row][col] == target:
                return (row, col)
    return None

zombie_position = find_position(game_map, 0)
player_position = find_position(game_map, 9)
VISION_RADIUS = 2

# print("초기 맵 상태:")
# print_map(game_map)
#
# #range횟수만큼 틱수 설정.
# for tick in range(300):
#     zombie_position = zombie_tick(zombie_position, player_position, game_map, VISION_RADIUS)
#     print(f"틱 {tick + 1}:")
#     print_map(game_map)
#
# print(f"최종 좀비 위치: {zombie_position}")